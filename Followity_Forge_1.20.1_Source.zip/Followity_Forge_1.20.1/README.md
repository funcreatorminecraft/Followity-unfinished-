# Followity — Forge 1.20.1

Created for **FunCreatorMinecraft**.

## Requirements
- Minecraft Java Edition 1.20.1
- Minecraft Forge 47.2.0
- Java 17
- Gradle 8.x (or open this folder in a Gradle-capable IDE)

## Build
Run `gradle build`. The mod jar should appear in `build/libs/`.
For a development client, run `gradle runClient`.

## Test
Install the resulting jar in your Forge `mods` folder and use:
`/summon followity:followity`

Followity follows nearby players while friendly. On the first evening after spawning it greets the nearest player; on the second it warns that this is its last day. On the third evening it switches to the horror texture and attacks players. Story state is saved with the entity.

## Important
This is a source project scaffold, not a precompiled or ForgeGradle-verified jar. Build and test it in a local Forge development environment; fix any version-specific compile/runtime issues that appear. The textures are generated placeholders included with the source.
