package com.funcreatorminecraft.followity;
import com.funcreatorminecraft.followity.registry.ModEntities;
import com.funcreatorminecraft.followity.entity.FollowityEntity;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(FollowityMod.MOD_ID)
public class FollowityMod {
    public static final String MOD_ID = "followity";
    public FollowityMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITY_TYPES.register(bus);
        bus.addListener(this::attributes);
    }
    private void attributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.FOLLOWITY.get(), FollowityEntity.createAttributes().build());
    }
}
