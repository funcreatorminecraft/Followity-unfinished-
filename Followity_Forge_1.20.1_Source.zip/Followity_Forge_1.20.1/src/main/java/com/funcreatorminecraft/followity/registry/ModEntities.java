package com.funcreatorminecraft.followity.registry;
import com.funcreatorminecraft.followity.FollowityMod;
import com.funcreatorminecraft.followity.entity.FollowityEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
        DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, FollowityMod.MOD_ID);
    public static final RegistryObject<EntityType<FollowityEntity>> FOLLOWITY = ENTITY_TYPES.register("followity",
        () -> EntityType.Builder.of(FollowityEntity::new, MobCategory.CREATURE)
            .sized(0.8F, 1.15F).clientTrackingRange(10).build("followity"));
    private ModEntities() {}
}
