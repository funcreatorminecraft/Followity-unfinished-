package com.funcreatorminecraft.followity.client;
import com.funcreatorminecraft.followity.FollowityMod;
import com.funcreatorminecraft.followity.entity.FollowityEntity;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;

public class FollowityRenderer extends MobRenderer<FollowityEntity,FollowityModel> {
    private static final ResourceLocation FRIENDLY = new ResourceLocation(FollowityMod.MOD_ID,"textures/entity/followity.png");
    private static final ResourceLocation HORROR = new ResourceLocation(FollowityMod.MOD_ID,"textures/entity/followity_horror.png");
    public FollowityRenderer(EntityRendererProvider.Context c) {
        super(c,new FollowityModel(c.bakeLayer(FollowityModel.LAYER)),0.45F);
    }
    @Override public ResourceLocation getTextureLocation(FollowityEntity e) { return e.isTransformed()?HORROR:FRIENDLY; }
}
