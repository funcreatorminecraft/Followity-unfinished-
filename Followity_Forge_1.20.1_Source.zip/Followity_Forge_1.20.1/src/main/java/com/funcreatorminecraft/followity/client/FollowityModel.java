package com.funcreatorminecraft.followity.client;
import com.funcreatorminecraft.followity.FollowityMod;
import com.funcreatorminecraft.followity.entity.FollowityEntity;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.*;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class FollowityModel extends HierarchicalModel<FollowityEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(new ResourceLocation(FollowityMod.MOD_ID, "followity"), "main");
    private final ModelPart root, body, head;
    public FollowityModel(ModelPart root) { this.root=root; body=root.getChild("body"); head=body.getChild("head"); }
    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition body = root.addOrReplaceChild("body",
            CubeListBuilder.create().texOffs(0,0).addBox(-5,-7,-4,10,10,8), PartPose.offset(0,17,0));
        PartDefinition head = body.addOrReplaceChild("head",
            CubeListBuilder.create().texOffs(0,18).addBox(-4,-7,-4,8,8,8), PartPose.offset(0,-4,0));
        head.addOrReplaceChild("left_eye", CubeListBuilder.create().texOffs(32,0).addBox(-2.5F,-4.5F,-4.35F,2,2,1), PartPose.ZERO);
        head.addOrReplaceChild("right_eye", CubeListBuilder.create().texOffs(32,0).addBox(0.5F,-4.5F,-4.35F,2,2,1), PartPose.ZERO);
        return LayerDefinition.create(mesh,64,64);
    }
    @Override public ModelPart root() { return root; }
    @Override public void setupAnim(FollowityEntity e,float limb,float amount,float age,float yaw,float pitch) {
        head.yRot=yaw*((float)Math.PI/180F); head.xRot=pitch*((float)Math.PI/180F);
        body.y=17+Mth.sin(age*0.12F)*0.45F;
        body.xRot=e.isTransformed()?0.08F:0.0F;
    }
}
