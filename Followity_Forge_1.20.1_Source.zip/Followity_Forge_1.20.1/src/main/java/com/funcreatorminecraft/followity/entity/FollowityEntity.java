package com.funcreatorminecraft.followity.entity;
import com.funcreatorminecraft.followity.registry.ModEntities;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import java.util.EnumSet;

public class FollowityEntity extends PathfinderMob {
    private static final EntityDataAccessor<Boolean> TRANSFORMED =
        SynchedEntityData.defineId(FollowityEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> STAGE =
        SynchedEntityData.defineId(FollowityEntity.class, EntityDataSerializers.INT);
    private long spawnDay = -1;
    private int lastEvening = 0;

    public FollowityEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        setPersistenceRequired();
    }
    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes().add(Attributes.MAX_HEALTH, 24.0)
            .add(Attributes.MOVEMENT_SPEED, 0.27).add(Attributes.FOLLOW_RANGE, 24.0)
            .add(Attributes.ATTACK_DAMAGE, 5.0).add(Attributes.ARMOR, 2.0);
    }
    @Override protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(TRANSFORMED, false);
        entityData.define(STAGE, 0);
    }
    @Override protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new FollowPlayerGoal(this));
        goalSelector.addGoal(2, new LookAtPlayerGoal(this, Player.class, 12.0F));
        goalSelector.addGoal(3, new RandomLookAroundGoal(this));
        goalSelector.addGoal(4, new MeleeAttackGoal(this, 1.2D, true));
        targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true, p -> isTransformed()));
    }
    @Override public void tick() {
        super.tick();
        if (level().isClientSide || !(level() instanceof ServerLevel server)) return;
        long day = server.getDayTime() / 24000L;
        if (spawnDay < 0) spawnDay = day;
        long time = server.getDayTime() % 24000L;
        if (time < 12000L || time >= 23000L) return;
        int evening = (int)(day - spawnDay + 1);
        if (evening <= lastEvening) return;
        Player player = server.getNearestPlayer(this, 20.0);
        if (player == null) return;
        if (evening == 1) {
            player.sendSystemMessage(Component.literal("§6Followity§f: Hey. I'll stay with you."));
            entityData.set(STAGE, 1);
        } else if (evening == 2) {
            player.sendSystemMessage(Component.literal("§6Followity§f: This is my last day with you."));
            entityData.set(STAGE, 2);
        } else if (evening >= 3 && !isTransformed()) {
            entityData.set(TRANSFORMED, true);
            entityData.set(STAGE, 3);
            setCustomName(Component.literal("Followity"));
            setCustomNameVisible(true);
            setHealth(getMaxHealth());
            player.sendSystemMessage(Component.literal("§cFollowity§f: You should not have trusted me."));
            level().broadcastEntityEvent(this, (byte)60);
        }
        lastEvening = evening;
    }
    public boolean isTransformed() { return entityData.get(TRANSFORMED); }
    public int getStoryStage() { return entityData.get(STAGE); }
    @Override public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Transformed", isTransformed());
        tag.putInt("StoryStage", getStoryStage());
        tag.putLong("SpawnDay", spawnDay);
        tag.putInt("LastEvening", lastEvening);
    }
    @Override public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        entityData.set(TRANSFORMED, tag.getBoolean("Transformed"));
        entityData.set(STAGE, tag.getInt("StoryStage"));
        spawnDay = tag.getLong("SpawnDay");
        lastEvening = tag.getInt("LastEvening");
    }
    private static class FollowPlayerGoal extends Goal {
        private final FollowityEntity mob;
        private Player player;
        FollowPlayerGoal(FollowityEntity mob) { this.mob = mob; setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK)); }
        @Override public boolean canUse() {
            if (mob.isTransformed()) return false;
            player = mob.level().getNearestPlayer(mob, 18.0);
            return player != null && mob.distanceToSqr(player) > 9.0;
        }
        @Override public boolean canContinueToUse() {
            return !mob.isTransformed() && player != null && player.isAlive()
                && mob.distanceToSqr(player) > 4.0 && mob.distanceToSqr(player) < 648.0;
        }
        @Override public void tick() {
            if (player == null) return;
            mob.getLookControl().setLookAt(player, 10.0F, mob.getMaxHeadXRot());
            if (mob.distanceToSqr(player) > 9.0) mob.getNavigation().moveTo(player, 1.15D);
            else mob.getNavigation().stop();
        }
        @Override public void stop() { player = null; mob.getNavigation().stop(); }
    }
}
