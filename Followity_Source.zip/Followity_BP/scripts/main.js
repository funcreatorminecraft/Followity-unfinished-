import { world, system, Entity, Player, Dimension, GameMode } from "@minecraft/server";

/**
 * FOLLOWITY — the orange companion.
 * This script is intentionally organized into systems so it's easy to expand.
 * Commands:
 *   /scriptevent followity:spawn
 *   /scriptevent followity:reset
 *   /scriptevent followity:status
 *   /scriptevent followity:language en
 *   /scriptevent followity:language fr
 *
 * Note: This is a starter Bedrock add-on. Bedrock APIs and entity rendering can
 * vary by version. Enable Beta APIs / Script API if your world requires it.
 */

const CONFIG = {
  entityId: "followity:followity",
  tickRate: 20,
  followDistance: 3.2,
  catchupDistance: 14,
  spawnDistance: 2,
  nightStart: 13000,
  nightEnd: 23000,
  thirdNightDanger: true,
  useActionBar: true,
  maxDialogueDistance: 32,
  languageDefault: "en",
  companionName: "FOLLOWITY",
  version: "1.0.0"
};

const PHASE = Object.freeze({
  UNKNOWN: 0,
  FRIENDLY: 1,
  LAST_EVENING: 2,
  HUNTING: 3,
  RECOVERED: 4
});

const LANGUAGES = Object.freeze({
  en: "English",
  fr: "Français"
});

const STRINGS = {
  en: {
    spawned: "§6FOLLOWITY§r: Hiii! I found you!",
    already: "§6FOLLOWITY§r: I'm already here. Look around.",
    reset: "§6FOLLOWITY§r: Everything is normal again. Probably.",
    status: "§6FOLLOWITY§r: Phase {phase} | Evening {evening} | Language {language}",
    language: "§6FOLLOWITY§r: Language set to English.",
    missing: "§6FOLLOWITY§r: I can't find you. That's weird.",
    day1: [
      "Hey! I'm Followity. I'll stick with you!",
      "You can build a house. I'll judge the windows.",
      "Do you think orange is a good color? I do.",
      "I can keep up. Probably. Don't sprint.",
      "I like your world. It has a lot of places to hide.",
      "If you hear footsteps, that's probably me.",
      "I don't need sleep. I can watch the sunrise.",
      "Can we explore over there? Please?",
      "I remember every block you've placed. Kidding!",
      "You're my favorite person in this world."
    ],
    day2: [
      "Can we go somewhere quiet this evening?",
      "I have something I need to tell you.",
      "The sky looks different tonight, doesn't it?",
      "I wish we had more time to explore.",
      "You have been very kind to me.",
      "Promise you'll remember me?",
      "I think this is my last evening.",
      "Don't be upset. I knew this day would come.",
      "I don't want to leave you alone.",
      "Stay close to me tonight. Please."
    ],
    night3: [
      "You came back.",
      "I said I would always follow you.",
      "Why are you running? I missed you.",
      "You don't have to be scared of me.",
      "I can still hear you, even over there.",
      "I remember every step we took.",
      "You said we were friends.",
      "Don't make me chase you.",
      "I'm still Followity. Mostly.",
      "Come back. I just want to talk."
    ],
    distant: [
      "Hey! You're getting far away!",
      "Wait for me!",
      "I can't see you very well from here.",
      "You know I don't like being left behind."
    ],
    close: [
      "There you are!",
      "I knew you'd come back.",
      "You walk so fast.",
      "I was right behind you. The whole time."
    ],
    last: "I think... this is my last evening with you.",
    transformed: "§cFOLLOWITY§r: You left me here. Now follow ME.",
    hunting: [
      "§cFOLLOWITY§r: KEEP RUNNING.",
      "§cFOLLOWITY§r: I can find you anywhere.",
      "§cFOLLOWITY§r: Why won't you wait for me?",
      "§cFOLLOWITY§r: I only want to stay together.",
      "§cFOLLOWITY§r: I can see you."
    ],
    calm: "§6FOLLOWITY§r: It's okay. I'm right here.",
    blocked: "§6FOLLOWITY§r: I can't get through there. Move a little?",
    commandHelp: "§eFollowity commands: spawn, reset, status, language en|fr",
    unknownCommand: "§cFollowity doesn't understand that command."
  },
  fr: {
    spawned: "§6FOLLOWITY§r : Coucou ! Je t'ai trouvé !",
    already: "§6FOLLOWITY§r : Je suis déjà là. Regarde autour de toi.",
    reset: "§6FOLLOWITY§r : Tout est redevenu normal. Enfin, je crois.",
    status: "§6FOLLOWITY§r : Phase {phase} | Soir {evening} | Langue {language}",
    language: "§6FOLLOWITY§r : Langue réglée sur le français.",
    missing: "§6FOLLOWITY§r : Je ne te trouve pas. C'est bizarre.",
    day1: [
      "Salut ! Je suis Followity. Je vais te suivre !",
      "Tu peux construire une maison. Je jugerai les fenêtres.",
      "Tu crois que l'orange est une bonne couleur ? Moi, oui.",
      "Je peux te suivre. Probablement. Ne sprinte pas.",
      "J'aime bien ton monde. Il y a plein d'endroits où se cacher.",
      "Si tu entends des pas, c'est sûrement moi.",
      "Je n'ai pas besoin de dormir. Je peux regarder le soleil se lever.",
      "On peut explorer par là ? S'il te plaît ?",
      "Je me souviens de chaque bloc que tu poses. Je plaisante !",
      "Tu es ma personne préférée dans ce monde."
    ],
    day2: [
      "On peut aller dans un endroit calme ce soir ?",
      "J'ai quelque chose à te dire.",
      "Le ciel a l'air différent ce soir, non ?",
      "J'aimerais qu'on ait plus de temps pour explorer.",
      "Tu as été très gentil avec moi.",
      "Promets-moi que tu te souviendras de moi ?",
      "Je crois que c'est mon dernier soir.",
      "Ne sois pas triste. Je savais que ce jour arriverait.",
      "Je ne veux pas te laisser seul.",
      "Reste près de moi ce soir. S'il te plaît."
    ],
    night3: [
      "Tu es revenu.",
      "J'avais dit que je te suivrais toujours.",
      "Pourquoi tu cours ? Tu m'as manqué.",
      "Tu n'as pas besoin d'avoir peur de moi.",
      "Je t'entends, même de là-bas.",
      "Je me souviens de chaque pas qu'on a fait.",
      "Tu avais dit qu'on était amis.",
      "Ne m'oblige pas à te poursuivre.",
      "Je suis toujours Followity. En grande partie.",
      "Reviens. Je veux juste parler."
    ],
    distant: [
      "Hé ! Tu t'éloignes !",
      "Attends-moi !",
      "Je ne te vois pas très bien d'ici.",
      "Tu sais que je n'aime pas être abandonné."
    ],
    close: [
      "Te voilà !",
      "Je savais que tu reviendrais.",
      "Tu marches vraiment vite.",
      "J'étais juste derrière toi. Tout le temps."
    ],
    last: "Je crois que... c'est mon dernier soir avec toi.",
    transformed: "§cFOLLOWITY§r : Tu m'as laissé ici. Maintenant, suis-MOI.",
    hunting: [
      "§cFOLLOWITY§r : CONTINUE DE COURIR.",
      "§cFOLLOWITY§r : Je peux te trouver partout.",
      "§cFOLLOWITY§r : Pourquoi tu ne m'attends pas ?",
      "§cFOLLOWITY§r : Je veux juste qu'on reste ensemble.",
      "§cFOLLOWITY§r : Je te vois."
    ],
    calm: "§6FOLLOWITY§r : Ça va. Je suis juste là.",
    blocked: "§6FOLLOWITY§r : Je ne peux pas passer. Bouge un peu ?",
    commandHelp: "§eCommandes Followity : spawn, reset, status, language en|fr",
    unknownCommand: "§cFollowity ne comprend pas cette commande."
  }
};

const STATE = new Map();
const PLAYER_MEMORY = new Map();
const RECENT_LINES = new Map();

function playerKey(player) {
  return player.id;
}

function getPlayerState(player) {
  const key = playerKey(player);
  if (!STATE.has(key)) {
    STATE.set(key, {
      phase: PHASE.UNKNOWN,
      evening: 0,
      language: CONFIG.languageDefault,
      spawned: false,
      lastDialogueTick: 0,
      lastPhaseTick: 0,
      lastPosition: { x: player.location.x, y: player.location.y, z: player.location.z },
      distance: 0,
      seenNightTwo: false,
      transformed: false,
      huntingLineTick: 0,
      lastWarnTick: 0,
      followityId: undefined
    });
  }
  return STATE.get(key);
}

function stringsFor(player) {
  const state = getPlayerState(player);
  return STRINGS[state.language] || STRINGS.en;
}

function format(text, replacements = {}) {
  let output = text;
  for (const [key, value] of Object.entries(replacements)) {
    output = output.replaceAll(`{${key}}`, String(value));
  }
  return output;
}

function say(player, text) {
  try {
    player.sendMessage(text);
  } catch (_) {}
}

function tell(player, key, replacements = {}) {
  const dictionary = stringsFor(player);
  const value = dictionary[key];
  if (typeof value === "string") {
    say(player, format(value, replacements));
  }
}

function chooseLine(player, bucket) {
  const dictionary = stringsFor(player);
  const lines = dictionary[bucket];
  if (!Array.isArray(lines) || lines.length === 0) return "";
  const key = `${playerKey(player)}:${bucket}`;
  const recent = RECENT_LINES.get(key) || [];
  let available = lines.map((line, index) => ({ line, index })).filter(item => !recent.includes(item.index));
  if (available.length === 0) available = lines.map((line, index) => ({ line, index }));
  const chosen = available[Math.floor(Math.random() * available.length)];
  recent.push(chosen.index);
  while (recent.length > Math.min(3, lines.length - 1)) recent.shift();
  RECENT_LINES.set(key, recent);
  return chosen.line;
}

function distance(a, b) {
  const dx = a.x - b.x;
  const dy = a.y - b.y;
  const dz = a.z - b.z;
  return Math.sqrt(dx * dx + dy * dy + dz * dz);
}

function getFollowity(player) {
  const state = getPlayerState(player);
  if (state.followityId) {
    try {
      const entity = player.dimension.getEntities({ type: CONFIG.entityId }).find(e => e.id === state.followityId);
      if (entity) return entity;
    } catch (_) {}
  }
  try {
    const nearby = player.dimension.getEntities({
      type: CONFIG.entityId,
      location: player.location,
      maxDistance: 48
    });
    if (nearby.length > 0) {
      state.followityId = nearby[0].id;
      return nearby[0];
    }
  } catch (_) {}
  return undefined;
}

function spawnFollowity(player) {
  const state = getPlayerState(player);
  const existing = getFollowity(player);
  if (existing) {
    state.spawned = true;
    tell(player, "already");
    return existing;
  }
  const location = {
    x: player.location.x + CONFIG.spawnDistance,
    y: player.location.y,
    z: player.location.z + CONFIG.spawnDistance
  };
  try {
    const entity = player.dimension.spawnEntity(CONFIG.entityId, location);
    state.followityId = entity.id;
    state.spawned = true;
    if (state.phase === PHASE.UNKNOWN) state.phase = PHASE.FRIENDLY;
    tell(player, "spawned");
    return entity;
  } catch (error) {
    say(player, "§cFollowity couldn't spawn. Check that the behavior pack is enabled.");
    return undefined;
  }
}

function removeFollowity(player) {
  try {
    const entity = getFollowity(player);
    if (entity) entity.remove();
  } catch (_) {}
  const state = getPlayerState(player);
  state.followityId = undefined;
  state.spawned = false;
}

function resetPlayer(player) {
  removeFollowity(player);
  STATE.set(playerKey(player), {
    phase: PHASE.UNKNOWN,
    evening: 0,
    language: CONFIG.languageDefault,
    spawned: false,
    lastDialogueTick: 0,
    lastPhaseTick: 0,
    lastPosition: { x: player.location.x, y: player.location.y, z: player.location.z },
    distance: 0,
    seenNightTwo: false,
    transformed: false,
    huntingLineTick: 0,
    lastWarnTick: 0,
    followityId: undefined
  });
  tell(player, "reset");
}

function getDayNumber() {
  try {
    return Math.floor(world.getAbsoluteTime() / 24000);
  } catch (_) {
    return 0;
  }
}

function getTimeOfDay() {
  try {
    return world.getTimeOfDay();
  } catch (_) {
    return 0;
  }
}

function isNight() {
  const time = getTimeOfDay();
  return time >= CONFIG.nightStart || time <= CONFIG.nightEnd - 24000;
}

function isEveningWindow() {
  const time = getTimeOfDay();
  return time >= 12000 && time <= 18000;
}

function isThirdNightWindow(state) {
  return state.evening >= 2 && (isNight() || isEveningWindow());
}

function updateEveningState(player, state) {
  const time = getTimeOfDay();
  const day = getDayNumber();
  const previous = PLAYER_MEMORY.get(playerKey(player)) || { day, wasNight: false, lastTime: time };
  const nowNight = time >= CONFIG.nightStart || time < 1000;
  const crossedEvening = !previous.wasNight && nowNight;
  if (crossedEvening) {
    state.evening = Math.max(state.evening, previous.eveningCount || 0) + 1;
    if (state.evening === 2 && state.phase < PHASE.LAST_EVENING) {
      state.phase = PHASE.LAST_EVENING;
      state.seenNightTwo = true;
      state.lastPhaseTick = system.currentTick;
      say(player, chooseLine(player, "day2"));
      if (CONFIG.useActionBar) {
        try { player.onScreenDisplay.setActionBar("§6Followity wants to show you something..."); } catch (_) {}
      }
    }
    if (state.evening >= 3 && CONFIG.thirdNightDanger && !state.transformed) {
      transformFollowity(player, state);
    }
  }
  PLAYER_MEMORY.set(playerKey(player), {
    day,
    wasNight: nowNight,
    lastTime: time,
    eveningCount: state.evening
  });
}

function transformFollowity(player, state) {
  state.phase = PHASE.HUNTING;
  state.transformed = true;
  state.lastPhaseTick = system.currentTick;
  const entity = getFollowity(player);
  if (entity) {
    try {
      entity.nameTag = "§cFOLLOWITY";
      entity.addTag("followity_hunting");
      entity.addEffect("speed", 20 * 60 * 10, { amplifier: 1, showParticles: false });
      entity.addEffect("resistance", 20 * 60 * 10, { amplifier: 2, showParticles: false });
    } catch (_) {}
  }
  tell(player, "transformed");
  try {
    player.dimension.spawnParticle("minecraft:basic_flame_particle", player.location);
    player.dimension.playSound("mob.endermen.stare", player.location, { volume: 1, pitch: 0.65 });
  } catch (_) {}
}

function nearestPlayer(entity) {
  try {
    const candidates = entity.dimension.getPlayers({ location: entity.location, maxDistance: 64 });
    let closest;
    let best = Infinity;
    for (const player of candidates) {
      const d = distance(entity.location, player.location);
      if (d < best) {
        best = d;
        closest = player;
      }
    }
    return closest;
  } catch (_) {
    return undefined;
  }
}

function teleportNearPlayer(entity, player) {
  const angle = Math.random() * Math.PI * 2;
  const radius = 2.5 + Math.random() * 2.0;
  const location = {
    x: player.location.x + Math.cos(angle) * radius,
    y: player.location.y,
    z: player.location.z + Math.sin(angle) * radius
  };
  try {
    entity.teleport(location, { dimension: player.dimension, checkForBlocks: true });
  } catch (_) {}
}

function moveToward(entity, target, speed = 0.18) {
  try {
    const dx = target.x - entity.location.x;
    const dy = target.y - entity.location.y;
    const dz = target.z - entity.location.z;
    const length = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
    entity.applyImpulse({
      x: (dx / length) * speed,
      y: Math.max(-0.05, Math.min(0.08, dy / length * speed)),
      z: (dz / length) * speed
    });
  } catch (_) {}
}

function friendlyBehavior(player, state, entity) {
  const d = distance(player.location, entity.location);
  state.distance = d;
  if (d > CONFIG.catchupDistance) {
    teleportNearPlayer(entity, player);
    if (system.currentTick - state.lastWarnTick > 20 * 8) {
      say(player, chooseLine(player, "distant"));
      state.lastWarnTick = system.currentTick;
    }
  } else if (d > CONFIG.followDistance) {
    moveToward(entity, player.location, 0.16);
  }
  if (d < 2.2 && system.currentTick - state.lastDialogueTick > 20 * 45) {
    say(player, chooseLine(player, "close"));
    state.lastDialogueTick = system.currentTick;
  }
  if (system.currentTick - state.lastDialogueTick > 20 * 75) {
    const bucket = state.evening >= 1 ? "day1" : "day1";
    say(player, chooseLine(player, bucket));
    state.lastDialogueTick = system.currentTick;
  }
  try {
    entity.nameTag = "§6Followity";
  } catch (_) {}
}

function lastEveningBehavior(player, state, entity) {
  const d = distance(player.location, entity.location);
  if (d > CONFIG.followDistance) moveToward(entity, player.location, 0.13);
  if (system.currentTick - state.lastDialogueTick > 20 * 55) {
    say(player, chooseLine(player, "day2"));
    state.lastDialogueTick = system.currentTick;
  }
  if (isNight() && system.currentTick - state.lastPhaseTick > 20 * 40) {
    if (!state.seenNightTwo) {
      tell(player, "last");
      state.seenNightTwo = true;
    }
    try {
      player.onScreenDisplay.setActionBar("§6Followity: §fStay with me a little longer...");
    } catch (_) {}
  }
}

function huntingBehavior(player, state, entity) {
  const d = distance(player.location, entity.location);
  if (d > 30) teleportNearPlayer(entity, player);
  else if (d > 1.7) moveToward(entity, player.location, 0.32);
  try {
    entity.nameTag = "§cFOLLOWITY";
    entity.addEffect("speed", 80, { amplifier: 1, showParticles: false });
    entity.addEffect("strength", 80, { amplifier: 0, showParticles: false });
  } catch (_) {}
  if (system.currentTick - state.huntingLineTick > 20 * 12) {
    say(player, chooseLine(player, "hunting"));
    state.huntingLineTick = system.currentTick;
  }
  if (d < 2.0 && system.currentTick - state.lastWarnTick > 20 * 5) {
    try {
      player.dimension.playSound("mob.endermen.stare", player.location, { volume: 0.8, pitch: 0.5 });
      player.dimension.spawnParticle("minecraft:basic_smoke_particle", entity.location);
    } catch (_) {}
    state.lastWarnTick = system.currentTick;
  }
}

function updatePlayer(player) {
  const state = getPlayerState(player);
  updateEveningState(player, state);
  let entity = getFollowity(player);
  if (!entity && state.spawned) {
    state.spawned = false;
    state.followityId = undefined;
  }
  if (!entity && state.phase === PHASE.UNKNOWN) return;
  if (!entity && state.phase !== PHASE.UNKNOWN) entity = spawnFollowity(player);
  if (!entity) return;

  if (state.phase === PHASE.HUNTING) {
    huntingBehavior(player, state, entity);
  } else if (state.phase === PHASE.LAST_EVENING) {
    lastEveningBehavior(player, state, entity);
  } else {
    friendlyBehavior(player, state, entity);
  }
  state.lastPosition = { x: player.location.x, y: player.location.y, z: player.location.z };
}

function safeRunForPlayers(callback) {
  for (const player of world.getAllPlayers()) {
    try {
      callback(player);
    } catch (error) {
      // Keep one player's error from stopping the entire companion system.
    }
  }
}

world.afterEvents.playerSpawn.subscribe((event) => {
  const player = event.player;
  system.runTimeout(() => {
    const state = getPlayerState(player);
    if (state.phase !== PHASE.UNKNOWN && !getFollowity(player)) spawnFollowity(player);
  }, 20);
});

world.afterEvents.scriptEventReceive.subscribe((event) => {
  const id = event.id;
  const source = event.sourceEntity;
  if (!source || source.typeId !== "minecraft:player") return;
  const player = source;
  const message = (event.message || "").trim().toLowerCase();
  const state = getPlayerState(player);

  if (id === "followity:spawn") {
    spawnFollowity(player);
    return;
  }
  if (id === "followity:reset") {
    resetPlayer(player);
    return;
  }
  if (id === "followity:status") {
    tell(player, "status", {
      phase: state.phase,
      evening: state.evening,
      language: LANGUAGES[state.language] || LANGUAGES.en
    });
    return;
  }
  if (id === "followity:language") {
    if (message === "fr" || message === "en") {
      state.language = message;
      tell(player, "language");
    } else {
      tell(player, "commandHelp");
    }
    return;
  }
  if (id === "followity:help") {
    tell(player, "commandHelp");
    return;
  }
  tell(player, "unknownCommand");
});

system.runInterval(() => {
  safeRunForPlayers(updatePlayer);
}, CONFIG.tickRate);

// Keep the source intentionally expanded with a large bank of optional ambient lines.
// These are loaded as data and can be extended without changing the behavior logic.

const AMBIENT_LINE_BANK = [
  "I was only a little bit behind you, promise.", // ambient line 001
  "Do you think the moon can see us?", // ambient line 002
  "I like it when you talk to me.", // ambient line 003
  "I heard something in the trees. It sounded familiar.", // ambient line 004
  "This place feels different after sunset.", // ambient line 005
  "I counted your footsteps. I lost count at 42.", // ambient line 006
  "If I stand very still, do I look like a pumpkin?", // ambient line 007
  "Your world is full of doors. I wonder where they all lead.", // ambient line 008
  "I found a place we should visit together.", // ambient line 009
  "I don't remember being this quiet before.", // ambient line 010
  "You can tell me anything. I will listen.", // ambient line 011
  "I don't get tired, but I can pretend.", // ambient line 012
  "I saw a light far away. It went out when I blinked.", // ambient line 013
  "Do you ever feel like the world is waiting?", // ambient line 014
  "I like the sound of rain on the roof.", // ambient line 015
  "I had a dream about a door with no handle.", // ambient line 016
  "I think the cave remembers us.", // ambient line 017
  "The stars look like little holes in the sky.", // ambient line 018
  "I was going to say something. I forgot what it was.", // ambient line 019
  "I will be right here when you get back.", // ambient line 020
  "I was only a little bit behind you, promise.", // ambient line 021
  "Do you think the moon can see us?", // ambient line 022
  "I like it when you talk to me.", // ambient line 023
  "I heard something in the trees. It sounded familiar.", // ambient line 024
  "This place feels different after sunset.", // ambient line 025
  "I counted your footsteps. I lost count at 182.", // ambient line 026
  "If I stand very still, do I look like a pumpkin?", // ambient line 027
  "Your world is full of doors. I wonder where they all lead.", // ambient line 028
  "I found a place we should visit together.", // ambient line 029
  "I don't remember being this quiet before.", // ambient line 030
  "You can tell me anything. I will listen.", // ambient line 031
  "I don't get tired, but I can pretend.", // ambient line 032
  "I saw a light far away. It went out when I blinked.", // ambient line 033
  "Do you ever feel like the world is waiting?", // ambient line 034
  "I like the sound of rain on the roof.", // ambient line 035
  "I had a dream about a door with no handle.", // ambient line 036
  "I think the cave remembers us.", // ambient line 037
  "The stars look like little holes in the sky.", // ambient line 038
  "I was going to say something. I forgot what it was.", // ambient line 039
  "I will be right here when you get back.", // ambient line 040
  "I was only a little bit behind you, promise.", // ambient line 041
  "Do you think the moon can see us?", // ambient line 042
  "I like it when you talk to me.", // ambient line 043
  "I heard something in the trees. It sounded familiar.", // ambient line 044
  "This place feels different after sunset.", // ambient line 045
  "I counted your footsteps. I lost count at 322.", // ambient line 046
  "If I stand very still, do I look like a pumpkin?", // ambient line 047
  "Your world is full of doors. I wonder where they all lead.", // ambient line 048
  "I found a place we should visit together.", // ambient line 049
  "I don't remember being this quiet before.", // ambient line 050
  "You can tell me anything. I will listen.", // ambient line 051
  "I don't get tired, but I can pretend.", // ambient line 052
  "I saw a light far away. It went out when I blinked.", // ambient line 053
  "Do you ever feel like the world is waiting?", // ambient line 054
  "I like the sound of rain on the roof.", // ambient line 055
  "I had a dream about a door with no handle.", // ambient line 056
  "I think the cave remembers us.", // ambient line 057
  "The stars look like little holes in the sky.", // ambient line 058
  "I was going to say something. I forgot what it was.", // ambient line 059
  "I will be right here when you get back.", // ambient line 060
  "I was only a little bit behind you, promise.", // ambient line 061
  "Do you think the moon can see us?", // ambient line 062
  "I like it when you talk to me.", // ambient line 063
  "I heard something in the trees. It sounded familiar.", // ambient line 064
  "This place feels different after sunset.", // ambient line 065
  "I counted your footsteps. I lost count at 462.", // ambient line 066
  "If I stand very still, do I look like a pumpkin?", // ambient line 067
  "Your world is full of doors. I wonder where they all lead.", // ambient line 068
  "I found a place we should visit together.", // ambient line 069
  "I don't remember being this quiet before.", // ambient line 070
  "You can tell me anything. I will listen.", // ambient line 071
  "I don't get tired, but I can pretend.", // ambient line 072
  "I saw a light far away. It went out when I blinked.", // ambient line 073
  "Do you ever feel like the world is waiting?", // ambient line 074
  "I like the sound of rain on the roof.", // ambient line 075
  "I had a dream about a door with no handle.", // ambient line 076
  "I think the cave remembers us.", // ambient line 077
  "The stars look like little holes in the sky.", // ambient line 078
  "I was going to say something. I forgot what it was.", // ambient line 079
  "I will be right here when you get back.", // ambient line 080
];

function getAmbientLine(index) {
  if (!AMBIENT_LINE_BANK.length) return "";
  const normalized = Math.abs(index) % AMBIENT_LINE_BANK.length;
  return AMBIENT_LINE_BANK[normalized];
}

function getFollowityDebugInfo(player) {
  const state = getPlayerState(player);
  return {
    player: player.name,
    phase: state.phase,
    evening: state.evening,
    language: state.language,
    spawned: state.spawned,
    transformed: state.transformed,
    distance: Math.round(state.distance * 100) / 100,
    entityId: state.followityId || null
  };
}

function broadcastDebugInfo() {
  for (const player of world.getAllPlayers()) {
    try {
      const info = getFollowityDebugInfo(player);
      if (player.hasTag("followity_debug")) {
        player.sendMessage("§8[Followity Debug] " + JSON.stringify(info));
      }
    } catch (_) {}
  }
}

// The debug interval is intentionally slow so it doesn't spam ordinary players.
system.runInterval(broadcastDebugInfo, 20 * 15);

// Explicit extension points for future features.
const EXTENSIONS = {
  achievements: [],
  quests: [],
  secretLocations: [],
  collectibleMemories: [],
  alternateForms: [],
  endingFlags: [],
  soundtrackCues: [],
  ambientParticles: [],
  rareDialogue: [],
  worldEvents: []
};

function registerExtension(category, value) {
  if (!Object.prototype.hasOwnProperty.call(EXTENSIONS, category)) return false;
  if (!Array.isArray(EXTENSIONS[category])) return false;
  EXTENSIONS[category].push(value);
  return true;
}

function listExtensions() {
  return Object.keys(EXTENSIONS).map(key => ({
    name: key,
    count: EXTENSIONS[key].length
  }));
}

// Keep the function references available for future edits and easy expansion.
const FOLLOWITY_API = {
  config: CONFIG,
  phases: PHASE,
  getPlayerState,
  getFollowity,
  spawnFollowity,
  removeFollowity,
  resetPlayer,
  chooseLine,
  getAmbientLine,
  getFollowityDebugInfo,
  registerExtension,
  listExtensions
};


// Extended archive: extra ambient lore lines for future story events.
const FOLLOWITY_ARCHIVE = [
  "I remember the first block you placed. (memory 1)",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows.",
  "I think this world has a memory.",
  "I heard your footsteps before you joined.",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting.",
  "If I disappear, count to ten.",
  "I like this place because you are here. (memory 10)",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way.",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset.",
  "I wonder if the world knows my name.",
  "I can follow you anywhere. That's my job. (memory 19)",
  "Let's stay together until morning.",
  "I remember the first block you placed.",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows.",
  "I think this world has a memory.",
  "I heard your footsteps before you joined.",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting. (memory 28)",
  "If I disappear, count to ten.",
  "I like this place because you are here.",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way.",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset. (memory 37)",
  "I wonder if the world knows my name.",
  "I can follow you anywhere. That's my job.",
  "Let's stay together until morning.",
  "I remember the first block you placed.",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows.",
  "I think this world has a memory.",
  "I heard your footsteps before you joined. (memory 46)",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting.",
  "If I disappear, count to ten.",
  "I like this place because you are here.",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way. (memory 55)",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset.",
  "I wonder if the world knows my name.",
  "I can follow you anywhere. That's my job.",
  "Let's stay together until morning.",
  "I remember the first block you placed.",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows. (memory 64)",
  "I think this world has a memory.",
  "I heard your footsteps before you joined.",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting.",
  "If I disappear, count to ten.",
  "I like this place because you are here.",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening? (memory 73)",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way.",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset.",
  "I wonder if the world knows my name.",
  "I can follow you anywhere. That's my job.",
  "Let's stay together until morning.",
  "I remember the first block you placed.",
  "The night is quieter when you are near. (memory 82)",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows.",
  "I think this world has a memory.",
  "I heard your footsteps before you joined.",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting.",
  "If I disappear, count to ten.",
  "I like this place because you are here.",
  "The cave sounds different after midnight. (memory 91)",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way.",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset.",
  "I wonder if the world knows my name.",
  "I can follow you anywhere. That's my job.",
  "Let's stay together until morning. (memory 100)",
  "I remember the first block you placed.",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows.",
  "I think this world has a memory.",
  "I heard your footsteps before you joined.",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting.",
  "If I disappear, count to ten. (memory 109)",
  "I like this place because you are here.",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way.",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset.",
  "I wonder if the world knows my name. (memory 118)",
  "I can follow you anywhere. That's my job.",
  "Let's stay together until morning.",
  "I remember the first block you placed.",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows.",
  "I think this world has a memory.",
  "I heard your footsteps before you joined.",
  "Sometimes the clouds look like doors. (memory 127)",
  "I don't mind waiting. I am good at waiting.",
  "If I disappear, count to ten.",
  "I like this place because you are here.",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way.",
  "I have a secret, but not yet. (memory 136)",
  "The sunrise always feels like a reset.",
  "I wonder if the world knows my name.",
  "I can follow you anywhere. That's my job.",
  "Let's stay together until morning.",
  "I remember the first block you placed.",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows.",
  "I think this world has a memory. (memory 145)",
  "I heard your footsteps before you joined.",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting.",
  "If I disappear, count to ten.",
  "I like this place because you are here.",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait. (memory 154)",
  "I never get lost. I just take the long way.",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset.",
  "I wonder if the world knows my name.",
  "I can follow you anywhere. That's my job.",
  "Let's stay together until morning.",
  "I remember the first block you placed.",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there. (memory 163)",
  "We should build a room with no windows.",
  "I think this world has a memory.",
  "I heard your footsteps before you joined.",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting.",
  "If I disappear, count to ten.",
  "I like this place because you are here.",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday. (memory 172)",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way.",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset.",
  "I wonder if the world knows my name.",
  "I can follow you anywhere. That's my job.",
  "Let's stay together until morning.",
  "I remember the first block you placed. (memory 181)",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows.",
  "I think this world has a memory.",
  "I heard your footsteps before you joined.",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting.",
  "If I disappear, count to ten.",
  "I like this place because you are here. (memory 190)",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way.",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset.",
  "I wonder if the world knows my name.",
  "I can follow you anywhere. That's my job. (memory 199)",
  "Let's stay together until morning.",
  "I remember the first block you placed.",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows.",
  "I think this world has a memory.",
  "I heard your footsteps before you joined.",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting. (memory 208)",
  "If I disappear, count to ten.",
  "I like this place because you are here.",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way.",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset. (memory 217)",
  "I wonder if the world knows my name.",
  "I can follow you anywhere. That's my job.",
  "Let's stay together until morning.",
  "I remember the first block you placed.",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows.",
  "I think this world has a memory.",
  "I heard your footsteps before you joined. (memory 226)",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting.",
  "If I disappear, count to ten.",
  "I like this place because you are here.",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way. (memory 235)",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset.",
  "I wonder if the world knows my name.",
  "I can follow you anywhere. That's my job.",
  "Let's stay together until morning.",
  "I remember the first block you placed.",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows. (memory 244)",
  "I think this world has a memory.",
  "I heard your footsteps before you joined.",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting.",
  "If I disappear, count to ten.",
  "I like this place because you are here.",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening? (memory 253)",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way.",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset.",
  "I wonder if the world knows my name.",
  "I can follow you anywhere. That's my job.",
  "Let's stay together until morning.",
  "I remember the first block you placed.",
  "The night is quieter when you are near. (memory 262)",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows.",
  "I think this world has a memory.",
  "I heard your footsteps before you joined.",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting.",
  "If I disappear, count to ten.",
  "I like this place because you are here.",
  "The cave sounds different after midnight. (memory 271)",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way.",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset.",
  "I wonder if the world knows my name.",
  "I can follow you anywhere. That's my job.",
  "Let's stay together until morning. (memory 280)",
  "I remember the first block you placed.",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows.",
  "I think this world has a memory.",
  "I heard your footsteps before you joined.",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting.",
  "If I disappear, count to ten. (memory 289)",
  "I like this place because you are here.",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way.",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset.",
  "I wonder if the world knows my name. (memory 298)",
  "I can follow you anywhere. That's my job.",
  "Let's stay together until morning.",
  "I remember the first block you placed.",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows.",
  "I think this world has a memory.",
  "I heard your footsteps before you joined.",
  "Sometimes the clouds look like doors. (memory 307)",
  "I don't mind waiting. I am good at waiting.",
  "If I disappear, count to ten.",
  "I like this place because you are here.",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way.",
  "I have a secret, but not yet. (memory 316)",
  "The sunrise always feels like a reset.",
  "I wonder if the world knows my name.",
  "I can follow you anywhere. That's my job.",
  "Let's stay together until morning.",
  "I remember the first block you placed.",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows.",
  "I think this world has a memory. (memory 325)",
  "I heard your footsteps before you joined.",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting.",
  "If I disappear, count to ten.",
  "I like this place because you are here.",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait. (memory 334)",
  "I never get lost. I just take the long way.",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset.",
  "I wonder if the world knows my name.",
  "I can follow you anywhere. That's my job.",
  "Let's stay together until morning.",
  "I remember the first block you placed.",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there. (memory 343)",
  "We should build a room with no windows.",
  "I think this world has a memory.",
  "I heard your footsteps before you joined.",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting.",
  "If I disappear, count to ten.",
  "I like this place because you are here.",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday. (memory 352)",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way.",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset.",
  "I wonder if the world knows my name.",
  "I can follow you anywhere. That's my job.",
  "Let's stay together until morning.",
  "I remember the first block you placed. (memory 361)",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows.",
  "I think this world has a memory.",
  "I heard your footsteps before you joined.",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting.",
  "If I disappear, count to ten.",
  "I like this place because you are here. (memory 370)",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way.",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset.",
  "I wonder if the world knows my name.",
  "I can follow you anywhere. That's my job. (memory 379)",
  "Let's stay together until morning.",
  "I remember the first block you placed.",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows.",
  "I think this world has a memory.",
  "I heard your footsteps before you joined.",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting. (memory 388)",
  "If I disappear, count to ten.",
  "I like this place because you are here.",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way.",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset. (memory 397)",
  "I wonder if the world knows my name.",
  "I can follow you anywhere. That's my job.",
  "Let's stay together until morning.",
  "I remember the first block you placed.",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows.",
  "I think this world has a memory.",
  "I heard your footsteps before you joined. (memory 406)",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting.",
  "If I disappear, count to ten.",
  "I like this place because you are here.",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way. (memory 415)",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset.",
  "I wonder if the world knows my name.",
  "I can follow you anywhere. That's my job.",
  "Let's stay together until morning.",
  "I remember the first block you placed.",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows. (memory 424)",
  "I think this world has a memory.",
  "I heard your footsteps before you joined.",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting.",
  "If I disappear, count to ten.",
  "I like this place because you are here.",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening? (memory 433)",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way.",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset.",
  "I wonder if the world knows my name.",
  "I can follow you anywhere. That's my job.",
  "Let's stay together until morning.",
  "I remember the first block you placed.",
  "The night is quieter when you are near. (memory 442)",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows.",
  "I think this world has a memory.",
  "I heard your footsteps before you joined.",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting.",
  "If I disappear, count to ten.",
  "I like this place because you are here.",
  "The cave sounds different after midnight. (memory 451)",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way.",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset.",
  "I wonder if the world knows my name.",
  "I can follow you anywhere. That's my job.",
  "Let's stay together until morning. (memory 460)",
  "I remember the first block you placed.",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows.",
  "I think this world has a memory.",
  "I heard your footsteps before you joined.",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting.",
  "If I disappear, count to ten. (memory 469)",
  "I like this place because you are here.",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way.",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset.",
  "I wonder if the world knows my name. (memory 478)",
  "I can follow you anywhere. That's my job.",
  "Let's stay together until morning.",
  "I remember the first block you placed.",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows.",
  "I think this world has a memory.",
  "I heard your footsteps before you joined.",
  "Sometimes the clouds look like doors. (memory 487)",
  "I don't mind waiting. I am good at waiting.",
  "If I disappear, count to ten.",
  "I like this place because you are here.",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way.",
  "I have a secret, but not yet. (memory 496)",
  "The sunrise always feels like a reset.",
  "I wonder if the world knows my name.",
  "I can follow you anywhere. That's my job.",
  "Let's stay together until morning.",
  "I remember the first block you placed.",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows.",
  "I think this world has a memory. (memory 505)",
  "I heard your footsteps before you joined.",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting.",
  "If I disappear, count to ten.",
  "I like this place because you are here.",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait. (memory 514)",
  "I never get lost. I just take the long way.",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset.",
  "I wonder if the world knows my name.",
  "I can follow you anywhere. That's my job.",
  "Let's stay together until morning.",
  "I remember the first block you placed.",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there. (memory 523)",
  "We should build a room with no windows.",
  "I think this world has a memory.",
  "I heard your footsteps before you joined.",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting.",
  "If I disappear, count to ten.",
  "I like this place because you are here.",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday. (memory 532)",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way.",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset.",
  "I wonder if the world knows my name.",
  "I can follow you anywhere. That's my job.",
  "Let's stay together until morning.",
  "I remember the first block you placed. (memory 541)",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows.",
  "I think this world has a memory.",
  "I heard your footsteps before you joined.",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting.",
  "If I disappear, count to ten.",
  "I like this place because you are here. (memory 550)",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way.",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset.",
  "I wonder if the world knows my name.",
  "I can follow you anywhere. That's my job. (memory 559)",
  "Let's stay together until morning.",
  "I remember the first block you placed.",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows.",
  "I think this world has a memory.",
  "I heard your footsteps before you joined.",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting. (memory 568)",
  "If I disappear, count to ten.",
  "I like this place because you are here.",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way.",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset. (memory 577)",
  "I wonder if the world knows my name.",
  "I can follow you anywhere. That's my job.",
  "Let's stay together until morning.",
  "I remember the first block you placed.",
  "The night is quieter when you are near.",
  "I saw a torch flicker when nobody was there.",
  "We should build a room with no windows.",
  "I think this world has a memory.",
  "I heard your footsteps before you joined. (memory 586)",
  "Sometimes the clouds look like doors.",
  "I don't mind waiting. I am good at waiting.",
  "If I disappear, count to ten.",
  "I like this place because you are here.",
  "The cave sounds different after midnight.",
  "I found a path that wasn't there yesterday.",
  "Do you remember what I said last evening?",
  "You don't have to answer. I can wait.",
  "I never get lost. I just take the long way. (memory 595)",
  "I have a secret, but not yet.",
  "The sunrise always feels like a reset.",
];
