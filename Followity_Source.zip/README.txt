# FOLLOWITY — Minecraft Bedrock Add-on

## Included
- Behavior pack + resource pack
- Orange companion entity named Followity
- Follows the player and occasionally speaks
- English and French dialogue
- Second-evening warning dialogue
- Third-evening horror phase
- Script-event commands

## Install
1. Import `Followity.mcaddon` into Minecraft Bedrock.
2. Create or edit a world and enable **Followity — Behavior Pack** and **Followity — Resource Pack**.
3. If your Bedrock version requires it, enable Script API / Beta APIs in world experiments.
4. In chat, run: `/scriptevent followity:spawn`
5. Optional: `/scriptevent followity:language fr` or `/scriptevent followity:language en`
6. Check status with `/scriptevent followity:status`
7. Reset the story with `/scriptevent followity:reset`

## Important compatibility note
This is a starter add-on and may need small updates for your exact Bedrock version. Custom entity geometry/rendering and Script API versions change between releases. If the entity appears invisible or fails to spawn, the script error log and current Bedrock version will help diagnose it. The supplied model mapping is a placeholder rather than a polished custom 3D model.

## Story logic
- First evening: friendly dialogue.
- Second evening: Followity says this may be its last evening.
- Third evening: Followity changes its name tag and enters a faster, ominous chase behavior.

The addon uses Minecraft time and the Script API; it does not contain real AI or online services.
